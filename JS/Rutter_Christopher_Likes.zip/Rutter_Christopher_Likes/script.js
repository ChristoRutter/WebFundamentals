function increaseLikes(element){
    element.innerHTML++
}