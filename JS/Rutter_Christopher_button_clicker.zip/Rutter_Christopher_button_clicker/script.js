function loginButton(element){
    element.innerText = `Logout`
}

function likeAlert(){
    alert('Ninja was liked')
}